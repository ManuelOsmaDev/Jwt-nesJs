export class CreateUserDto {
    name:string;
    password:string;
    rol:string;
}
