export const jwtConstants = {
    secret: "manuel"
}